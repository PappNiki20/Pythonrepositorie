def kor():
    index = 0
    szamok = []
    while index < 5:
        szam = int(input("Adjon meg egy kort! [0-120]"))
        szamok.append(szam)
        index += 1
    print(f"II/A, B, C:\n ")
    for i in range(len(szamok) - 1):
        print(f"\t{szamok[i]} ", end=":")
    print(f" {szamok[4]} ")
    print(f"II/D, E:\n ")


def elso_idos(szamok):
    index = 0
    for i in range(len(szamok)):
        if szamok[i] > 70:
            index = szamok[i]
    return index
