#import szam
#szam.szamok()

import korok
korok.kor()