import random


def szamok():
    szam = random.randint(1, 50)
    print(f"I/A: \n\tA generált szám: {szam}")
    szamvege = len(str(szam))
    if szamvege == 0 or szamvege == 5:
        print(f"I/B: \n\tA szám öttel osztható!")
    elif szamvege == 3:
        print(f"I/B: \n\tA szám hárommal osztható!")
    elif szam % 3 == 0 and szam % 5 == 0:
        print(f"I/B: \n\tA szám öttel és hárommal is osztható!")

